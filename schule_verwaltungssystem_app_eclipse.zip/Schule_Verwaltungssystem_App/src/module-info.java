module gp2_vorlageFX {
	exports view;
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.base;
}